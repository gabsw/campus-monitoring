
/*$(function() {

    $('.dropdown-toggle').on('click', function(event) {
        $('.dropdown-menu').slideToggle();
        event.stopPropagation();
    });

    $('.dropdown-menu').on('click', function(event) {
        event.stopPropagation();
    });

    $(window).on('click', function() {
        $('.dropdown-menu').slideUp();
    });

});*/